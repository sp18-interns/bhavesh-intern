package com.letslearn.myspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstSpringbootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
